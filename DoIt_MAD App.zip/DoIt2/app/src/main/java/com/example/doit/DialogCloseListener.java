package com.example.doit;

import android.app.Dialog;
import android.content.DialogInterface;

public interface DialogCloseListener {
    public void handleDialogClose(DialogInterface Dialog);
}
